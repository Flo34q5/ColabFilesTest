{
  "properties" : {
    "current.location" : "",
    "security.free.access.authorities" : ""
  },
  "import.local" : {
    "Homework9_Ontology;;homework9-ontology.ttl" : {
      "name" : "homework9-ontology.ttl",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "default",
      "replaceGraphs" : [ "default" ],
      "baseURI" : "file:/uploaded/generated/homework9-ontology.ttl",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "453bb8e9-761d-48f4-b723-41d4481e3166",
      "timestamp" : 1702626775070,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    },
    "homework9_ontology;;homework9-ontology.ttl" : {
      "name" : "homework9-ontology.ttl",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "default",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/homework9-ontology.ttl",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "9a9b1f12-abd8-434c-b786-1ef42f3418d2",
      "timestamp" : 1702626998529,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    },
    "h9;;homework9.nt" : {
      "name" : "homework9.nt",
      "status" : "NONE",
      "message" : "",
      "context" : null,
      "replaceGraphs" : [ ],
      "baseURI" : null,
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "800a0788-d0a7-43ac-93a6-505c7c232cb1",
      "timestamp" : 1734696375971,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    },
    "trial;;homework9.nt" : {
      "name" : "homework9.nt",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/homework9.nt",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "77170418-e27b-4eee-9365-e1100ca35672",
      "timestamp" : 1734696413695,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    },
    "disha_h9;;homework9.nt" : {
      "name" : "homework9.nt",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/homework9.nt",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "3c8fb55e-321f-478e-98b7-f499447f174c",
      "timestamp" : 1734701410396,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    },
    "homework9_provided_data;;homework9.nt" : {
      "name" : "homework9.nt",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "default",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/homework9.nt",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "3181a2b7-0866-483c-8c82-53a8b9b02458",
      "timestamp" : 1734704711462,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    }
  },
  "locations" : {
    "" : {
      "location" : "",
      "authType" : "none",
      "password" : null,
      "username" : null,
      "defaultRepository" : null
    }
  },
  "import.server" : { }
}